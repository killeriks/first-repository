# Hello World!
# My name is Vadym. I'm 15 years old.
## Now I'm studying in technikum#24 in Warszaw.
## I live in Warszaw( Poland ) but I'm from Ukraine.
In my free time i like:
* play computer games;
* meet friends;
* create new code;

**I can code on:**

*javaScript;

*HTML;

*CSS;

*and some C++;


![this is img](https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcTft8l7sDBSXAyDC4_LZ2stcivcVSrDORgywXLtf7yNPLqXhAPzFy0loBRAZqLhWRRqI_o&usqp=CAU)
